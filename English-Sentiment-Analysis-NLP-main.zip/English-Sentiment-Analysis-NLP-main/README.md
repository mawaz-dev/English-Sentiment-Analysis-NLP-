# English Sentiment Analysis

A lightweight NLP project for classifying English text as Positive or Negative using a machine learning pipeline and a small Flask web app.

## Overview

This project builds a sentiment classifier that analyzes user-provided text and predicts whether the tone is positive or negative. It combines:

- Text preprocessing (lowercasing, punctuation removal, stopword filtering)
- TF-IDF feature extraction
- Naive Bayes classification
- A simple Flask web interface for real-time prediction

## What the model does

The app takes raw English text, cleans it, converts it into numerical features using a TF-IDF vectorizer, and passes it to a trained Naive Bayes classifier.

Example:

- "I love this product!" -> Positive
- "This is terrible and frustrating." -> Negative

## Tech stack

- Python
- Flask
- scikit-learn
- NLTK
- joblib
- HTML/CSS/JavaScript for the UI

## Project structure

- `app.py` — Flask app with prediction endpoint and preprocessing logic
- `templates/index.html` — web UI for entering text and displaying the result
- `sentiment_data.csv` — training dataset
- `cleaned_sample_tweets.csv` and `sample_comments.csv` — sample data used for exploration/testing
- `tfidf_vectorizer.pkl` — saved TF-IDF vectorizer
- `naive_bayes_model.pkl` — trained model
- `requirements.txt` — project dependencies

## How it works

1. User enters text in the web interface or sends a POST request to `/predict`.
2. The text is cleaned by removing non-letter characters and common stopwords.
3. A TF-IDF vectorizer transforms the text into feature vectors.
4. The trained Naive Bayes model predicts the sentiment label.
5. The result is returned as JSON or displayed in the browser.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open:

```text
http://localhost:5000
```

## Prediction API

Endpoint:

```http
POST /predict
```

Form data:

```text
user_input=I love this product
```

Response:

```json
{"sentiment": "Positive"}
```

## Notes

- The model is trained for binary sentiment classification: Positive vs Negative.
- The preprocessing matches the training pipeline to maintain prediction consistency.
- This is a good starting project for NLP learning, text classification, and deployment basics.
