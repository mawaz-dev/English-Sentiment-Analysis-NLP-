from flask import Flask, request, render_template, jsonify
import joblib
import re
import nltk
from nltk.corpus import stopwords

# --- Initialize Flask app ---
app = Flask(__name__)

# --- Download and load stopwords ---
try:
    stop_words = set(stopwords.words('english'))
except LookupError:
    nltk.download('stopwords')
    stop_words = set(stopwords.words('english'))

# --- Load saved model & vectorizer ---
print("Loading model and vectorizer...")
vectorizer = joblib.load('tfidf_vectorizer.pkl')
model = joblib.load('naive_bayes_model.pkl')
print("Model and vectorizer loaded successfully!")

# --- Preprocess function (same as your training code) ---
def clean_text(text):
    """Clean text exactly as done during training"""
    text = re.sub(r'[^a-zA-Z\s]', '', text)  # Remove non-letters
    text = text.lower()                       # Lowercase
    text = ' '.join(word for word in text.split() if word not in stop_words)  # Remove stopwords
    return text

# --- Route to serve the HTML page ---
@app.route("/")
def index():
    return render_template("index.html")

# --- Route to handle predictions ---
@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Get user input from form
        user_input = request.form.get("user_input", "").strip()
        
        if not user_input:
            return jsonify({"error": "No input provided"}), 400
        
        print(f"Received input: {user_input}")
        
        # Clean the input text
        cleaned_input = clean_text(user_input)
        print(f"Cleaned input: {cleaned_input}")
        
        # Transform using TF-IDF vectorizer
        x_test_tfidf = vectorizer.transform([cleaned_input])
        
        # Make prediction
        prediction = model.predict(x_test_tfidf)[0]
        print(f"Prediction: {prediction}")
        
        # Convert prediction to sentiment label
        # Based on your training code: 0 = Negative, 2 = Positive
        sentiment = "Positive" if prediction == 2 else "Negative"
        
        return jsonify({"sentiment": sentiment})
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)